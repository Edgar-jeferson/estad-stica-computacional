import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from scipy.cluster.hierarchy import dendrogram, linkage
import warnings
warnings.filterwarnings('ignore')

# Configuración de la página
st.set_page_config(
    page_title="Análisis de Clustering ENAHO",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Título principal
st.title("📊 Análisis de Clustering - Datos ENAHO")
st.markdown("---")

# Valores considerados como "missing" en ENAHO
VALORES_MISSING = [99, 999, 9999, 99999, 999999, 9999999, 99999999]

# Variables disponibles para el clustering
VARIABLES_DISPONIBLES = {
    "P104": "Número de habitaciones",
    "P105B": "Monto mensual por alquiler",
    "P106": "Valor estimado del alquiler mensual",
    "P110C1": "Horas de agua al día",
    "P110C2": "Días de agua a la semana",
    "P117T2": "Gasto mensual por miembros del hogar",
    "P117T3": "Gasto mensual donado",
    "P117T4": "Gasto mensual por autoconsumo"
}

# Funciones auxiliares
@st.cache_data
def cargar_y_limpiar_datos(df, variables_seleccionadas, umbral_columnas=0.5, umbral_filas=0.7, metodo_imputacion='mean'):
    """Limpia y prepara los datos para clustering"""
    df_work = df.copy()
    
    # Convertir a numérico y reemplazar valores missing
    for col in variables_seleccionadas:
        if col in df_work.columns:
            df_work[col] = pd.to_numeric(df_work[col], errors='coerce')
            df_work[col] = df_work[col].replace(VALORES_MISSING, np.nan)
    
    # Filtrar solo las variables seleccionadas
    df_filtrado = df_work[variables_seleccionadas].copy()
    
    # Eliminar columnas con muchos valores nulos
    columnas_validas = df_filtrado.loc[:, df_filtrado.isnull().mean() < umbral_columnas].columns
    df_filtrado = df_filtrado[columnas_validas]
    
    if df_filtrado.empty:
        return df_filtrado
    
    # Eliminar filas con muchos valores nulos
    df_filtrado = df_filtrado[df_filtrado.isnull().mean(axis=1) < (1 - umbral_filas)]
    
    # Verificar si quedan datos después de la limpieza
    if df_filtrado.empty:
        return df_filtrado
    
    # Imputar valores faltantes restantes
    if df_filtrado.isnull().sum().sum() > 0:
        if metodo_imputacion == 'mean':
            # Imputar con la media
            df_filtrado = df_filtrado.fillna(df_filtrado.mean())
        elif metodo_imputacion == 'median':
            # Imputar con la mediana
            df_filtrado = df_filtrado.fillna(df_filtrado.median())
        elif metodo_imputacion == 'mode':
            # Imputar con la moda
            df_filtrado = df_filtrado.fillna(df_filtrado.mode().iloc[0])
        elif metodo_imputacion == 'drop':
            # Eliminar filas con cualquier valor nulo
            df_filtrado = df_filtrado.dropna()
    
    # Verificación final: eliminar cualquier NaN restante
    df_filtrado = df_filtrado.dropna()
    
    return df_filtrado

@st.cache_data
def calcular_metricas_clusters(datos_escalados, max_clusters=10):
    """Calcula métricas para diferentes números de clusters"""
    metricas = []
    
    for k in range(2, max_clusters + 1):
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        etiquetas = kmeans.fit_predict(datos_escalados)
        
        inercia = kmeans.inertia_
        silhouette = silhouette_score(datos_escalados, etiquetas)
        
        metricas.append({
            'clusters': k,
            'inercia': inercia,
            'silhouette': silhouette
        })
    
    return pd.DataFrame(metricas)

def aplicar_clustering(df, n_clusters=3):
    """Aplica clustering K-Means"""
    scaler = StandardScaler()
    datos_escalados = scaler.fit_transform(df)
    
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    etiquetas = kmeans.fit_predict(datos_escalados)
    
    return datos_escalados, etiquetas, kmeans, scaler

def crear_visualizaciones(df, datos_escalados, etiquetas, variables_seleccionadas):
    """Crea visualizaciones del clustering"""
    
    # PCA para visualización
    pca = PCA(n_components=2)
    componentes_pca = pca.fit_transform(datos_escalados)
    
    # Crear DataFrame para visualización
    df_viz = pd.DataFrame({
        'PC1': componentes_pca[:, 0],
        'PC2': componentes_pca[:, 1],
        'Cluster': etiquetas
    })
    
    # Gráfico PCA con Plotly
    fig_pca = px.scatter(
        df_viz, 
        x='PC1', 
        y='PC2', 
        color='Cluster',
        color_continuous_scale='viridis',
        title='Clusters visualizados con PCA',
        labels={'PC1': f'PC1 ({pca.explained_variance_ratio_[0]:.2%} varianza)',
                'PC2': f'PC2 ({pca.explained_variance_ratio_[1]:.2%} varianza)'}
    )
    fig_pca.update_layout(height=500)
    
    return fig_pca, pca

# Sidebar
st.sidebar.title("⚙️ Configuración")

# Carga de datos
st.sidebar.subheader("1. Cargar Datos")
archivo_subido = st.sidebar.file_uploader(
    "Selecciona el archivo CSV de ENAHO",
    type=['csv'],
    help="Sube tu archivo CSV con datos de ENAHO"
)

if archivo_subido is not None:
    # Cargar datos
    try:
        df = pd.read_csv(archivo_subido, encoding='latin1', low_memory=False)
        st.sidebar.success(f"✅ Archivo cargado: {archivo_subido.name}")
        st.sidebar.info(f"📋 Dimensiones: {df.shape[0]:,} filas × {df.shape[1]:,} columnas")
    except Exception as e:
        st.sidebar.error(f"❌ Error al cargar el archivo: {str(e)}")
        st.stop()
    
    # Selección de variables
    st.sidebar.subheader("2. Seleccionar Variables")
    variables_disponibles_en_df = [var for var in VARIABLES_DISPONIBLES.keys() if var in df.columns]
    
    if not variables_disponibles_en_df:
        st.sidebar.error("❌ No se encontraron las variables esperadas en el dataset")
        st.stop()
    
    variables_seleccionadas = st.sidebar.multiselect(
        "Selecciona las variables para clustering:",
        options=variables_disponibles_en_df,
        default=variables_disponibles_en_df,
        format_func=lambda x: f"{x} - {VARIABLES_DISPONIBLES[x]}"
    )
    
    if not variables_seleccionadas:
        st.sidebar.warning("⚠️ Selecciona al menos una variable")
        st.stop()
    
    # Parámetros de limpieza
    st.sidebar.subheader("3. Parámetros de Limpieza")
    umbral_columnas = st.sidebar.slider(
        "Umbral de valores nulos por columna",
        min_value=0.1,
        max_value=0.9,
        value=0.5,
        step=0.1,
        help="Columnas con más de este % de valores nulos serán eliminadas"
    )
    
    umbral_filas = st.sidebar.slider(
        "Umbral de datos válidos por fila",
        min_value=0.1,
        max_value=0.9,
        value=0.7,
        step=0.1,
        help="Filas con menos de este % de datos válidos serán eliminadas"
    )
    
    metodo_imputacion = st.sidebar.selectbox(
        "Método de imputación para valores faltantes",
        options=['mean', 'median', 'mode', 'drop'],
        index=0,
        help="Método para manejar valores faltantes restantes"
    )
    
    metodo_labels = {
        'mean': 'Media',
        'median': 'Mediana', 
        'mode': 'Moda',
        'drop': 'Eliminar filas'
    }
    st.sidebar.info(f"Método seleccionado: {metodo_labels[metodo_imputacion]}")
    
    # Procesar datos
    with st.spinner("🔄 Procesando datos..."):
        df_limpio = cargar_y_limpiar_datos(df, variables_seleccionadas, umbral_columnas, umbral_filas, metodo_imputacion)
    
    if df_limpio.empty:
        st.error("❌ No hay datos suficientes después de la limpieza. Ajusta los parámetros.")
        st.info("💡 Sugerencias:")
        st.write("- Reduce el umbral de valores nulos por columna")
        st.write("- Reduce el umbral de datos válidos por fila") 
        st.write("- Cambia el método de imputación a 'Media' o 'Mediana'")
        st.write("- Selecciona menos variables para el análisis")
        st.stop()
    
    # Verificar que no hay valores nulos después de la limpieza
    if df_limpio.isnull().sum().sum() > 0:
        st.warning("⚠️ Aún hay valores faltantes después de la limpieza. Eliminando automáticamente...")
        df_limpio = df_limpio.dropna()
        
        if df_limpio.empty:
            st.error("❌ No quedan datos después de eliminar valores faltantes.")
            st.stop()
    
    # Mostrar información sobre valores faltantes
    st.subheader("🧹 Información de Limpieza de Datos")
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("📊 Observaciones", f"{df_limpio.shape[0]:,}")
    with col2:
        st.metric("📋 Variables", f"{df_limpio.shape[1]}")
    with col3:
        completitud = (1 - df_limpio.isnull().sum().sum() / df_limpio.size) * 100
        st.metric("🧹 Completitud", f"{completitud:.1f}%")
    with col4:
        valores_inf = np.isinf(df_limpio.select_dtypes(include=[np.number]).values).sum()
        st.metric("♾️ Valores infinitos", f"{valores_inf}")
    
    # Mostrar resumen de valores faltantes si los hay
    if df_limpio.isnull().sum().sum() > 0:
        st.warning("⚠️ Hay valores faltantes restantes:")
        missing_info = df_limpio.isnull().sum()
        missing_info = missing_info[missing_info > 0]
        st.dataframe(missing_info.to_frame("Valores faltantes"))
    else:
        st.success("✅ No hay valores faltantes en los datos finales")
    
    # Estadísticas descriptivas
    st.subheader("📈 Estadísticas Descriptivas")
    with st.expander("Ver estadísticas detalladas"):
        st.dataframe(df_limpio.describe())
    
    # Análisis de clustering
    st.subheader("🔍 Análisis de Clustering")
    
    # Calcular métricas
    scaler = StandardScaler()
    datos_escalados = scaler.fit_transform(df_limpio)
    metricas_df = calcular_metricas_clusters(datos_escalados)
    
    # Visualizar métricas
    col1, col2 = st.columns(2)
    
    with col1:
        fig_elbow = px.line(
            metricas_df, 
            x='clusters', 
            y='inercia',
            title='Método del Codo (Elbow)',
            markers=True
        )
        fig_elbow.update_layout(height=400)
        st.plotly_chart(fig_elbow, use_container_width=True)
    
    with col2:
        fig_silhouette = px.line(
            metricas_df, 
            x='clusters', 
            y='silhouette',
            title='Coeficiente de Silhouette',
            markers=True
        )
        fig_silhouette.update_layout(height=400)
        st.plotly_chart(fig_silhouette, use_container_width=True)
    
    # Selección del número de clusters
    st.sidebar.subheader("4. Número de Clusters")
    
    # Sugerir número óptimo basado en silhouette
    mejor_k = metricas_df.loc[metricas_df['silhouette'].idxmax(), 'clusters']
    st.sidebar.info(f"💡 Número óptimo sugerido: {mejor_k} clusters")
    
    n_clusters = st.sidebar.slider(
        "Número de clusters:",
        min_value=2,
        max_value=10,
        value=int(mejor_k),
        step=1
    )
    
    # Aplicar clustering
    datos_escalados, etiquetas, kmeans, scaler = aplicar_clustering(df_limpio, n_clusters)
    
    # Crear visualizaciones
    fig_pca, pca = crear_visualizaciones(df_limpio, datos_escalados, etiquetas, variables_seleccionadas)
    
    # Mostrar resultados
    st.subheader("🎯 Resultados del Clustering")
    
    # Visualización PCA
    st.plotly_chart(fig_pca, use_container_width=True)
    
    # Resumen por cluster
    df_con_clusters = df_limpio.copy()
    df_con_clusters['Cluster'] = etiquetas
    
    resumen_clusters = df_con_clusters.groupby('Cluster').agg(['mean', 'count']).round(2)
    
    st.subheader("📊 Resumen por Cluster")
    
    # Mostrar información de cada cluster
    for i in range(n_clusters):
        with st.expander(f"Cluster {i} ({sum(etiquetas == i):,} observaciones)"):
            cluster_data = df_con_clusters[df_con_clusters['Cluster'] == i]
            st.dataframe(cluster_data.describe())
    
    # Matriz de correlación por cluster
    st.subheader("🔗 Análisis de Correlaciones")
    
    fig_corr = go.Figure()
    
    for i in range(n_clusters):
        cluster_data = df_con_clusters[df_con_clusters['Cluster'] == i][variables_seleccionadas]
        corr_matrix = cluster_data.corr()
        
        fig_corr.add_trace(go.Heatmap(
            z=corr_matrix.values,
            x=corr_matrix.columns,
            y=corr_matrix.columns,
            colorscale='RdBu',
            zmid=0,
            visible=True if i == 0 else False,
            name=f'Cluster {i}'
        ))
    
    # Crear botones para cambiar entre clusters
    buttons = []
    for i in range(n_clusters):
        visibility = [False] * n_clusters
        visibility[i] = True
        buttons.append(dict(
            label=f'Cluster {i}',
            method='update',
            args=[{'visible': visibility}]
        ))
    
    fig_corr.update_layout(
        title='Matriz de Correlación por Cluster',
        updatemenus=[dict(
            type='buttons',
            direction='row',
            buttons=buttons,
            x=0.5,
            y=1.15,
            xanchor='center'
        )],
        height=500
    )
    
    st.plotly_chart(fig_corr, use_container_width=True)
    
    # Exportar resultados
    st.subheader("💾 Exportar Resultados")
    
    if st.button("Descargar resultados como CSV"):
        csv = df_con_clusters.to_csv(index=False)
        st.download_button(
            label="📥 Descargar CSV",
            data=csv,
            file_name=f"resultados_clustering_{n_clusters}_clusters.csv",
            mime="text/csv"
        )
    
    # Métricas finales
    st.subheader("📈 Métricas de Calidad")
    
    silhouette_final = silhouette_score(datos_escalados, etiquetas)
    inercia_final = kmeans.inertia_
    
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Coeficiente de Silhouette", f"{silhouette_final:.3f}")
    with col2:
        st.metric("Inercia", f"{inercia_final:.2f}")
    with col3:
        st.metric("Varianza explicada PCA", f"{sum(pca.explained_variance_ratio_):.2%}")

else:
    st.info("👆 Sube un archivo CSV de ENAHO para comenzar el análisis")
    
    # Mostrar información sobre las variables
    st.subheader("📋 Variables Disponibles para Clustering")
    
    variables_info = pd.DataFrame([
        {"Código": k, "Descripción": v} 
        for k, v in VARIABLES_DISPONIBLES.items()
    ])
    
    st.dataframe(variables_info, use_container_width=True)
    
    st.subheader("ℹ️ Información sobre la Aplicación")
    st.markdown("""
    Esta aplicación permite realizar análisis de clustering sobre datos de la Encuesta Nacional de Hogares (ENAHO).
    
    **Características principales:**
    - 🔄 Limpieza automática de datos
    - 📊 Visualización interactiva de clusters
    - 📈 Métricas de calidad (Silhouette, Elbow)
    - 🎯 Análisis detallado por cluster
    - 💾 Exportación de resultados
    
    **Pasos para usar la aplicación:**
    1. Sube tu archivo CSV de ENAHO
    2. Selecciona las variables para el clustering
    3. Ajusta los parámetros de limpieza
    4. Visualiza las métricas y selecciona el número de clusters
    5. Analiza los resultados y exporta si es necesario
    """)