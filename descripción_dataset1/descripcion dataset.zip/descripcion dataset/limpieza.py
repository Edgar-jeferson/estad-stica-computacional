import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import io

# Configuración de la página
st.set_page_config(
    page_title="Detector de Outliers ENAHO",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Valores comúnmente usados como "missing" en ENAHO y otras encuestas
VALORES_MISSING = [99, 999, 9999, 99999, 999999, 9999999, 99999999]

@st.cache_data
def detectar_y_limpiar_outliers(df, metodo="IQR", factor_iqr=1.5):
    """
    Detecta y limpia outliers usando diferentes métodos.
    
    Args:
        df: DataFrame de pandas
        metodo: 'IQR', 'Z-Score', 'Percentil'
        factor_iqr: Factor para el método IQR (default: 1.5)
    
    Returns:
        resumen_outliers: DataFrame con estadísticas
        df_limpio: DataFrame limpio
        outliers_info: Información detallada de outliers
    """
    resumen_outliers = []
    outliers_info = {}
    df_limpio = df.copy()
    
    # Seleccionar solo columnas numéricas
    columnas_numericas = df.select_dtypes(include=[np.number]).columns
    
    for col in columnas_numericas:
        # Reemplazar valores missing
        df_limpio[col] = df_limpio[col].replace(VALORES_MISSING, np.nan)
        data = df_limpio[col].dropna()
        
        if data.empty:
            continue
        
        # Calcular límites según el método seleccionado
        if metodo == "IQR":
            Q1 = data.quantile(0.25)
            Q3 = data.quantile(0.75)
            IQR = Q3 - Q1
            lim_inf = Q1 - factor_iqr * IQR
            lim_sup = Q3 + factor_iqr * IQR
        elif metodo == "Z-Score":
            media = data.mean()
            std = data.std()
            lim_inf = media - 3 * std
            lim_sup = media + 3 * std
        elif metodo == "Percentil":
            lim_inf = data.quantile(0.05)
            lim_sup = data.quantile(0.95)
        
        # Detectar outliers
        outliers_mask = (data < lim_inf) | (data > lim_sup)
        outliers = data[outliers_mask]
        
        # Guardar información detallada de outliers
        outliers_info[col] = {
            'valores': outliers.values,
            'indices': outliers.index.tolist(),
            'limite_inf': lim_inf,
            'limite_sup': lim_sup
        }
        
        # Estadísticas descriptivas
        stats = {
            "Variable": col,
            "N Datos": len(data),
            "Valores Missing": df[col].isna().sum(),
            "Outliers Detectados": len(outliers),
            "% Outliers": round((len(outliers) / len(data)) * 100, 2),
            "Media": round(data.mean(), 2),
            "Mediana": round(data.median(), 2),
            "Desv. Estándar": round(data.std(), 2),
            "Mínimo": data.min(),
            "Máximo": data.max(),
            "Límite Inferior": round(lim_inf, 2),
            "Límite Superior": round(lim_sup, 2)
        }
        
        resumen_outliers.append(stats)
        
        # Marcar outliers como NaN si se solicita limpieza
        df_limpio.loc[(df_limpio[col] < lim_inf) | (df_limpio[col] > lim_sup), col] = np.nan
    
    return pd.DataFrame(resumen_outliers), df_limpio, outliers_info

def crear_boxplot(df, columna, outliers_info):
    """Crear boxplot interactivo con outliers destacados"""
    fig = go.Figure()
    
    data = df[columna].dropna()
    
    if not data.empty:
        fig.add_trace(go.Box(
            y=data,
            name=columna,
            boxpoints='outliers',
            jitter=0.3,
            pointpos=-1.8,
            marker=dict(color='red', size=4),
            line=dict(color='blue')
        ))
        
        # Añadir líneas de límites
        if columna in outliers_info:
            lim_inf = outliers_info[columna]['limite_inf']
            lim_sup = outliers_info[columna]['limite_sup']
            
            fig.add_hline(y=lim_inf, line_dash="dash", line_color="red", 
                         annotation_text=f"Límite Inferior: {lim_inf:.2f}")
            fig.add_hline(y=lim_sup, line_dash="dash", line_color="red", 
                         annotation_text=f"Límite Superior: {lim_sup:.2f}")
    
    fig.update_layout(
        title=f"Distribución y Outliers - {columna}",
        yaxis_title="Valores",
        height=400
    )
    
    return fig

def crear_histograma(df, columna):
    """Crear histograma con estadísticas"""
    data = df[columna].dropna()
    
    if not data.empty:
        fig = px.histogram(
            data, 
            title=f"Distribución de {columna}",
            nbins=30,
            labels={'value': columna, 'count': 'Frecuencia'}
        )
        
        # Añadir líneas de estadísticas
        fig.add_vline(x=data.mean(), line_dash="dash", line_color="red", 
                     annotation_text=f"Media: {data.mean():.2f}")
        fig.add_vline(x=data.median(), line_dash="dash", line_color="green", 
                     annotation_text=f"Mediana: {data.median():.2f}")
        
        fig.update_layout(height=400)
        return fig
    
    return None

def main():
    st.title("🔍 Detector de Outliers - Encuestas ENAHO")
    st.markdown("**Herramienta para detectar y limpiar valores atípicos en datasets de encuestas**")
    
    # Sidebar para configuración
    st.sidebar.header("⚙️ Configuración")
    
    # Método de detección
    metodo = st.sidebar.selectbox(
        "Método de detección:",
        ["IQR", "Z-Score", "Percentil"],
        help="IQR: Rango intercuartílico, Z-Score: Puntuación Z, Percentil: Percentiles 5-95"
    )
    
    # Factor IQR si se selecciona ese método
    factor_iqr = 1.5
    if metodo == "IQR":
        factor_iqr = st.sidebar.slider(
            "Factor IQR:",
            min_value=1.0,
            max_value=3.0,
            value=1.5,
            step=0.1,
            help="Factor multiplicador para el rango intercuartílico"
        )
    
    # Subir archivo
    uploaded_file = st.file_uploader(
        "📁 Selecciona tu archivo CSV",
        type=['csv'],
        help="Sube un archivo CSV con datos de encuestas"
    )
    
    if uploaded_file is not None:
        try:
            # Leer archivo
            df = pd.read_csv(uploaded_file, encoding='latin1', low_memory=False)
            
            st.success(f"✅ Archivo cargado exitosamente: {uploaded_file.name}")
            st.info(f"**Dimensiones:** {df.shape[0]:,} filas × {df.shape[1]:,} columnas")
            
            # Mostrar primeras filas
            with st.expander("🔍 Vista previa de los datos"):
                st.dataframe(df.head(), use_container_width=True)
            
            # Procesar datos
            with st.spinner("Procesando datos y detectando outliers..."):
                resumen, df_limpio, outliers_info = detectar_y_limpiar_outliers(
                    df, metodo=metodo, factor_iqr=factor_iqr
                )
            
            # Tabs para organizar resultados
            tab1, tab2, tab3, tab4 = st.tabs(["📊 Resumen", "📈 Visualizaciones", "🔍 Detalles", "💾 Descargar"])
            
            with tab1:
                st.header("📊 Resumen de Anomalías Detectadas")
                
                if not resumen.empty:
                    # Métricas principales
                    col1, col2, col3, col4 = st.columns(4)
                    with col1:
                        st.metric("Variables Numéricas", len(resumen))
                    with col2:
                        st.metric("Total Outliers", resumen['Outliers Detectados'].sum())
                    with col3:
                        st.metric("Promedio % Outliers", f"{resumen['% Outliers'].mean():.1f}%")
                    with col4:
                        variables_con_outliers = (resumen['Outliers Detectados'] > 0).sum()
                        st.metric("Variables con Outliers", variables_con_outliers)
                    
                    # Tabla de resumen
                    st.subheader("Tabla de Estadísticas por Variable")
                    st.dataframe(resumen, use_container_width=True)
                    
                    # Gráfico de barras con outliers por variable
                    fig_bar = px.bar(
                        resumen.sort_values('Outliers Detectados', ascending=False).head(10),
                        x='Variable',
                        y='Outliers Detectados',
                        title="Top 10 Variables con Más Outliers",
                        color='% Outliers',
                        color_continuous_scale='Reds'
                    )
                    fig_bar.update_layout(xaxis_tickangle=-45)
                    st.plotly_chart(fig_bar, use_container_width=True)
                else:
                    st.warning("No se encontraron variables numéricas para analizar.")
            
            with tab2:
                st.header("📈 Visualizaciones de Outliers")
                
                if not resumen.empty:
                    # Selector de variable
                    variables_con_outliers = resumen[resumen['Outliers Detectados'] > 0]['Variable'].tolist()
                    
                    if variables_con_outliers:
                        variable_seleccionada = st.selectbox(
                            "Selecciona una variable para visualizar:",
                            variables_con_outliers
                        )
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            # Boxplot
                            fig_box = crear_boxplot(df, variable_seleccionada, outliers_info)
                            st.plotly_chart(fig_box, use_container_width=True)
                        
                        with col2:
                            # Histograma
                            fig_hist = crear_histograma(df, variable_seleccionada)
                            if fig_hist:
                                st.plotly_chart(fig_hist, use_container_width=True)
                    else:
                        st.info("No se detectaron outliers en ninguna variable.")
            
            with tab3:
                st.header("🔍 Detalles de Outliers")
                
                if not resumen.empty and variables_con_outliers:
                    variable_detalle = st.selectbox(
                        "Selecciona una variable para ver detalles:",
                        variables_con_outliers,
                        key="detalle_select"
                    )
                    
                    if variable_detalle in outliers_info:
                        info = outliers_info[variable_detalle]
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("Límite Inferior", f"{info['limite_inf']:.2f}")
                        with col2:
                            st.metric("Límite Superior", f"{info['limite_sup']:.2f}")
                        
                        st.subheader("Valores Outliers Detectados")
                        if len(info['valores']) > 0:
                            outliers_df = pd.DataFrame({
                                'Índice': info['indices'],
                                'Valor': info['valores']
                            })
                            st.dataframe(outliers_df, use_container_width=True)
                        else:
                            st.info("No se encontraron outliers para esta variable.")
            
            with tab4:
                st.header("💾 Descargar Resultados")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.subheader("Dataset Limpio")
                    csv_limpio = df_limpio.to_csv(index=False)
                    st.download_button(
                        label="📥 Descargar CSV Limpio",
                        data=csv_limpio,
                        file_name=f"{uploaded_file.name.replace('.csv', '')}_limpio.csv",
                        mime="text/csv"
                    )
                
                with col2:
                    st.subheader("Reporte de Outliers")
                    csv_reporte = resumen.to_csv(index=False)
                    st.download_button(
                        label="📥 Descargar Reporte",
                        data=csv_reporte,
                        file_name=f"{uploaded_file.name.replace('.csv', '')}_reporte_outliers.csv",
                        mime="text/csv"
                    )
                
                # Información adicional
                st.subheader("ℹ️ Información sobre la Limpieza")
                st.info(f"""
                **Método utilizado:** {metodo}
                **Factor IQR:** {factor_iqr if metodo == 'IQR' else 'N/A'}
                **Valores considerados missing:** {', '.join(map(str, VALORES_MISSING))}
                **Total de outliers detectados:** {resumen['Outliers Detectados'].sum() if not resumen.empty else 0}
                """)
        
        except Exception as e:
            st.error(f"❌ Error al procesar el archivo: {str(e)}")
            st.info("💡 Intenta verificar que el archivo sea un CSV válido con codificación UTF-8 o Latin1")

if __name__ == "__main__":
    main()