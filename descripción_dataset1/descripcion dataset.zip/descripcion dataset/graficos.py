import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import seaborn as sns
import matplotlib.pyplot as plt

# Configuración de la página
st.set_page_config(
    page_title="Generador de Gráficos CSV",
    page_icon="📊",
    layout="wide"
)

# Valores considerados como missing
VALORES_MISSING = [99, 999, 9999, 99999, 999999, 9999999, 99999999]

def limpiar_datos(df):
    """Limpia los datos reemplazando valores missing y convirtiendo a numérico"""
    df_limpio = df.copy()
    
    # Reemplazar valores missing en columnas numéricas
    columnas_numericas = df_limpio.select_dtypes(include=[np.number]).columns
    for col in columnas_numericas:
        df_limpio[col] = df_limpio[col].replace(VALORES_MISSING, np.nan)
    
    return df_limpio

def crear_histogramas(df, columnas_numericas):
    """Crea histogramas para múltiples variables"""
    if len(columnas_numericas) == 0:
        return None
    
    # Calcular número de filas y columnas para subplots
    n_vars = len(columnas_numericas)
    cols = min(3, n_vars)
    rows = (n_vars + cols - 1) // cols
    
    fig = make_subplots(
        rows=rows, 
        cols=cols,
        subplot_titles=columnas_numericas,
        vertical_spacing=0.08,
        horizontal_spacing=0.05
    )
    
    for i, col in enumerate(columnas_numericas):
        row = i // cols + 1
        col_pos = i % cols + 1
        
        data = df[col].dropna()
        
        if not data.empty:
            fig.add_trace(
                go.Histogram(
                    x=data,
                    name=col,
                    nbinsx=30,
                    showlegend=False,
                    opacity=0.7
                ),
                row=row, col=col_pos
            )
    
    fig.update_layout(
        height=300 * rows,
        title_text="Distribución de Variables Numéricas",
        showlegend=False
    )
    
    return fig

def crear_boxplots(df, columnas_numericas):
    """Crea boxplots para múltiples variables"""
    if len(columnas_numericas) == 0:
        return None
    
    fig = go.Figure()
    
    for col in columnas_numericas:
        data = df[col].dropna()
        if not data.empty:
            fig.add_trace(
                go.Box(
                    y=data,
                    name=col,
                    boxpoints='outliers',
                    jitter=0.3,
                    pointpos=-1.8
                )
            )
    
    fig.update_layout(
        title="Boxplots - Detección de Outliers",
        yaxis_title="Valores",
        xaxis_title="Variables",
        height=600
    )
    
    return fig

def crear_matriz_correlacion(df, columnas_numericas):
    """Crea matriz de correlación"""
    if len(columnas_numericas) < 2:
        return None
    
    # Calcular correlación solo con columnas numéricas
    data_numeric = df[columnas_numericas].select_dtypes(include=[np.number])
    corr_matrix = data_numeric.corr()
    
    fig = px.imshow(
        corr_matrix,
        text_auto=True,
        aspect="auto",
        title="Matriz de Correlación",
        color_continuous_scale='RdBu_r',
        zmin=-1,
        zmax=1
    )
    
    fig.update_layout(height=600)
    return fig

def crear_grafico_dispersion(df, var_x, var_y):
    """Crea gráfico de dispersión entre dos variables"""
    data_x = df[var_x].dropna()
    data_y = df[var_y].dropna()
    
    # Crear DataFrame temporal para el gráfico
    df_temp = pd.DataFrame({
        var_x: data_x,
        var_y: data_y
    }).dropna()
    
    if df_temp.empty:
        return None
    
    fig = px.scatter(
        df_temp, 
        x=var_x, 
        y=var_y,
        title=f"Gráfico de Dispersión: {var_x} vs {var_y}",
        trendline="ols",
        opacity=0.6
    )
    
    fig.update_layout(height=500)
    return fig

def crear_grafico_barras(df, columna, top_n=15):
    """Crea gráfico de barras para variables categóricas"""
    if df[columna].dtype == 'object' or df[columna].nunique() < 50:
        # Para variables categóricas
        conteos = df[columna].value_counts().head(top_n)
        
        fig = px.bar(
            x=conteos.index,
            y=conteos.values,
            title=f"Frecuencia de {columna} (Top {top_n})",
            labels={'x': columna, 'y': 'Frecuencia'}
        )
        
        fig.update_layout(
            xaxis_tickangle=-45,
            height=500
        )
        
        return fig
    
    return None

def crear_grafico_lineas(df, columna_x, columna_y):
    """Crea gráfico de líneas"""
    df_temp = df[[columna_x, columna_y]].dropna()
    
    if df_temp.empty:
        return None
    
    # Agrupar por columna_x y calcular promedio
    df_grouped = df_temp.groupby(columna_x)[columna_y].mean().reset_index()
    
    fig = px.line(
        df_grouped,
        x=columna_x,
        y=columna_y,
        title=f"Tendencia: {columna_y} por {columna_x}",
        markers=True
    )
    
    fig.update_layout(height=500)
    return fig

def main():
    st.title("📊 Generador de Gráficos para CSV")
    st.markdown("**Crea visualizaciones interactivas de tus datos de forma rápida y sencilla**")
    
    # Sidebar
    st.sidebar.header("🎯 Opciones de Visualización")
    
    # Cargar archivo
    uploaded_file = st.file_uploader(
        "📁 Sube tu archivo CSV",
        type=['csv'],
        help="Selecciona un archivo CSV para generar gráficos"
    )
    
    if uploaded_file is not None:
        try:
            # Leer archivo
            df = pd.read_csv(uploaded_file, encoding='latin1', low_memory=False)
            df = limpiar_datos(df)
            
            st.success(f"✅ Archivo cargado: {uploaded_file.name}")
            st.info(f"📊 Dimensiones: {df.shape[0]:,} filas × {df.shape[1]:,} columnas")
            
            # Identificar tipos de columnas
            columnas_numericas = df.select_dtypes(include=[np.number]).columns.tolist()
            columnas_categoricas = df.select_dtypes(include=['object']).columns.tolist()
            
            # Filtrar columnas numéricas con pocos valores únicos
            columnas_numericas = [col for col in columnas_numericas if df[col].nunique() > 2]
            
            # Sidebar - Selección de gráficos
            st.sidebar.subheader("🎨 Tipos de Gráficos")
            
            mostrar_histogramas = st.sidebar.checkbox("📈 Histogramas", value=True)
            mostrar_boxplots = st.sidebar.checkbox("📦 Boxplots", value=True)
            mostrar_correlacion = st.sidebar.checkbox("🔗 Matriz de Correlación", value=True)
            mostrar_dispersion = st.sidebar.checkbox("🎯 Gráfico de Dispersión", value=False)
            mostrar_barras = st.sidebar.checkbox("📊 Gráfico de Barras", value=False)
            mostrar_lineas = st.sidebar.checkbox("📈 Gráfico de Líneas", value=False)
            
            # Tabs para organizar gráficos
            tabs = []
            tab_names = []
            
            if mostrar_histogramas and columnas_numericas:
                tab_names.append("📈 Histogramas")
            if mostrar_boxplots and columnas_numericas:
                tab_names.append("📦 Boxplots")
            if mostrar_correlacion and len(columnas_numericas) >= 2:
                tab_names.append("🔗 Correlación")
            if mostrar_dispersion and len(columnas_numericas) >= 2:
                tab_names.append("🎯 Dispersión")
            if mostrar_barras and columnas_categoricas:
                tab_names.append("📊 Barras")
            if mostrar_lineas and len(columnas_numericas) >= 2:
                tab_names.append("📈 Líneas")
            
            if tab_names:
                tabs = st.tabs(tab_names)
                tab_index = 0
                
                # Histogramas
                if mostrar_histogramas and columnas_numericas:
                    with tabs[tab_index]:
                        st.header("📈 Distribución de Variables")
                        
                        # Selector de variables
                        variables_hist = st.multiselect(
                            "Selecciona variables para histogramas:",
                            columnas_numericas,
                            default=columnas_numericas[:6]  # Máximo 6 por defecto
                        )
                        
                        if variables_hist:
                            fig_hist = crear_histogramas(df, variables_hist)
                            if fig_hist:
                                st.plotly_chart(fig_hist, use_container_width=True)
                    tab_index += 1
                
                # Boxplots
                if mostrar_boxplots and columnas_numericas:
                    with tabs[tab_index]:
                        st.header("📦 Detección de Outliers")
                        
                        variables_box = st.multiselect(
                            "Selecciona variables para boxplots:",
                            columnas_numericas,
                            default=columnas_numericas[:8]  # Máximo 8 por defecto
                        )
                        
                        if variables_box:
                            fig_box = crear_boxplots(df, variables_box)
                            if fig_box:
                                st.plotly_chart(fig_box, use_container_width=True)
                    tab_index += 1
                
                # Correlación
                if mostrar_correlacion and len(columnas_numericas) >= 2:
                    with tabs[tab_index]:
                        st.header("🔗 Matriz de Correlación")
                        
                        variables_corr = st.multiselect(
                            "Selecciona variables para correlación:",
                            columnas_numericas,
                            default=columnas_numericas[:10]  # Máximo 10 por defecto
                        )
                        
                        if len(variables_corr) >= 2:
                            fig_corr = crear_matriz_correlacion(df, variables_corr)
                            if fig_corr:
                                st.plotly_chart(fig_corr, use_container_width=True)
                    tab_index += 1
                
                # Dispersión
                if mostrar_dispersion and len(columnas_numericas) >= 2:
                    with tabs[tab_index]:
                        st.header("🎯 Gráfico de Dispersión")
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            var_x = st.selectbox("Variable X:", columnas_numericas, key="disp_x")
                        with col2:
                            var_y = st.selectbox("Variable Y:", columnas_numericas, key="disp_y")
                        
                        if var_x != var_y:
                            fig_disp = crear_grafico_dispersion(df, var_x, var_y)
                            if fig_disp:
                                st.plotly_chart(fig_disp, use_container_width=True)
                    tab_index += 1
                
                # Barras
                if mostrar_barras and columnas_categoricas:
                    with tabs[tab_index]:
                        st.header("📊 Gráfico de Barras")
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            var_cat = st.selectbox("Variable categórica:", columnas_categoricas + columnas_numericas)
                        with col2:
                            top_n = st.slider("Mostrar top N valores:", 5, 30, 15)
                        
                        fig_bar = crear_grafico_barras(df, var_cat, top_n)
                        if fig_bar:
                            st.plotly_chart(fig_bar, use_container_width=True)
                    tab_index += 1
                
                # Líneas
                if mostrar_lineas and len(columnas_numericas) >= 2:
                    with tabs[tab_index]:
                        st.header("📈 Gráfico de Líneas")
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            var_x_line = st.selectbox("Variable X:", columnas_numericas, key="line_x")
                        with col2:
                            var_y_line = st.selectbox("Variable Y:", columnas_numericas, key="line_y")
                        
                        if var_x_line != var_y_line:
                            fig_line = crear_grafico_lineas(df, var_x_line, var_y_line)
                            if fig_line:
                                st.plotly_chart(fig_line, use_container_width=True)
            
            else:
                st.warning("⚠️ No hay gráficos seleccionados o datos adecuados para mostrar.")
                st.info("💡 Selecciona al menos un tipo de gráfico en la barra lateral y asegúrate de que tu archivo contenga datos numéricos.")
            
            # Información adicional
            with st.expander("ℹ️ Información del Dataset"):
                col1, col2 = st.columns(2)
                with col1:
                    st.write("**Variables Numéricas:**")
                    if columnas_numericas:
                        for col in columnas_numericas:
                            st.write(f"• {col}")
                    else:
                        st.write("No se encontraron variables numéricas")
                
                with col2:
                    st.write("**Variables Categóricas:**")
                    if columnas_categoricas:
                        for col in columnas_categoricas[:10]:  # Mostrar solo las primeras 10
                            st.write(f"• {col}")
                        if len(columnas_categoricas) > 10:
                            st.write(f"... y {len(columnas_categoricas) - 10} más")
                    else:
                        st.write("No se encontraron variables categóricas")
        
        except Exception as e:
            st.error(f"❌ Error al cargar el archivo: {str(e)}")
            st.info("💡 Verifica que el archivo sea un CSV válido")

if __name__ == "__main__":
    main()