import streamlit as st
import pandas as pd
import numpy as np
from scipy import stats
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import io

# Configuración de la página
st.set_page_config(
    page_title="Analizador de Variables CSV",
    page_icon="📊",
    layout="wide"
)

# Variables que nos interesan
variables_relevantes = [
    "P104", "P104A", "P105B", "P106", "P110C1", "P110C2",
    "P117T2", "P117T3", "P117T4"
]

def calcular_estadisticas(df):
    """
    Calcula estadísticas descriptivas para las variables seleccionadas
    """
    estadisticas = []
    variables_encontradas = []
    variables_no_encontradas = []
    
    for var in variables_relevantes:
        if var not in df.columns:
            variables_no_encontradas.append(var)
            continue
            
        try:
            # Convertir a numérico y eliminar valores nulos
            data = pd.to_numeric(df[var], errors='coerce').dropna()
            
            if data.empty:
                variables_no_encontradas.append(f"{var} (sin datos válidos)")
                continue
            
            # Calcular moda de forma segura
            moda_values = data.mode()
            moda = moda_values.iloc[0] if not moda_values.empty else np.nan
            
            estadisticas.append({
                "Variable": var,
                "N_válidos": len(data),
                "Media": round(data.mean(), 2),
                "Mediana": round(data.median(), 2),
                "Moda": moda,
                "Desv_Estándar": round(data.std(), 2),
                "Mínimo": data.min(),
                "Máximo": data.max(),
                "Nulos": df[var].isnull().sum(),
                "Porcentaje_Nulos": round((df[var].isnull().sum() / len(df)) * 100, 2)
            })
            
            variables_encontradas.append(var)
            
        except Exception as e:
            variables_no_encontradas.append(f"{var} (error: {str(e)})")
            continue
    
    return pd.DataFrame(estadisticas), variables_encontradas, variables_no_encontradas

def crear_graficos(df, variables_encontradas):
    """
    Crea gráficos para las variables encontradas
    """
    if not variables_encontradas:
        return None
    
    # Crear subplots
    n_vars = len(variables_encontradas)
    cols = 2
    rows = (n_vars + 1) // 2
    
    fig = make_subplots(
        rows=rows, 
        cols=cols,
        subplot_titles=variables_encontradas,
        specs=[[{"secondary_y": False} for _ in range(cols)] for _ in range(rows)]
    )
    
    for i, var in enumerate(variables_encontradas):
        row = i // cols + 1
        col = i % cols + 1
        
        # Obtener datos válidos
        data = pd.to_numeric(df[var], errors='coerce').dropna()
        
        if not data.empty:
            # Histograma
            fig.add_trace(
                go.Histogram(
                    x=data,
                    name=var,
                    nbinsx=20,
                    showlegend=False
                ),
                row=row, col=col
            )
    
    fig.update_layout(
        height=300 * rows,
        title_text="Distribución de Variables",
        showlegend=False
    )
    
    return fig

def crear_boxplots(df, variables_encontradas):
    """
    Crea boxplots para las variables encontradas
    """
    if not variables_encontradas:
        return None
    
    fig = go.Figure()
    
    for var in variables_encontradas:
        data = pd.to_numeric(df[var], errors='coerce').dropna()
        if not data.empty:
            fig.add_trace(
                go.Box(
                    y=data,
                    name=var,
                    boxpoints='outliers'
                )
            )
    
    fig.update_layout(
        title="Boxplots de Variables",
        yaxis_title="Valores",
        xaxis_title="Variables",
        height=500
    )
    
    return fig

def crear_matriz_correlacion(df, variables_encontradas):
    """
    Crea matriz de correlación
    """
    if len(variables_encontradas) < 2:
        return None
    
    # Obtener datos numéricos
    data_numeric = pd.DataFrame()
    for var in variables_encontradas:
        data_numeric[var] = pd.to_numeric(df[var], errors='coerce')
    
    # Calcular correlación
    corr_matrix = data_numeric.corr()
    
    fig = px.imshow(
        corr_matrix,
        text_auto=True,
        aspect="auto",
        title="Matriz de Correlación",
        color_continuous_scale='RdBu'
    )
    
    return fig

# Interfaz principal
def main():
    st.title("📊 Analizador de Variables CSV")
    st.markdown("---")
    
    # Sidebar con información
    st.sidebar.header("📋 Variables a Analizar")
    st.sidebar.write("Este análisis buscará las siguientes variables:")
    for i, var in enumerate(variables_relevantes, 1):
        st.sidebar.write(f"{i}. **{var}**")
    
    st.sidebar.markdown("---")
    st.sidebar.info(
        "💡 **Tip**: Asegúrate de que tu archivo CSV contenga "
        "al menos algunas de estas variables para obtener resultados."
    )
    
    # Carga de archivo
    st.header("📂 Carga tu archivo CSV")
    uploaded_file = st.file_uploader(
        "Selecciona un archivo CSV",
        type=['csv'],
        help="Sube un archivo CSV que contenga las variables a analizar"
    )
    
    if uploaded_file is not None:
        try:
            # Mostrar información del archivo
            st.success(f"✅ Archivo cargado: **{uploaded_file.name}**")
            
            # Leer CSV
            with st.spinner("Cargando y procesando datos..."):
                df = pd.read_csv(uploaded_file, low_memory=False)
            
            # Información básica del dataset
            st.subheader("📋 Información del Dataset")
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Filas", f"{df.shape[0]:,}")
            with col2:
                st.metric("Columnas", f"{df.shape[1]:,}")
            with col3:
                st.metric("Memoria", f"{df.memory_usage(deep=True).sum() / 1024**2:.2f} MB")
            
            # Mostrar primeras filas
            with st.expander("👀 Ver primeras filas del dataset"):
                st.dataframe(df.head())
            
            # Mostrar columnas disponibles
            with st.expander("📑 Columnas disponibles en el dataset"):
                st.write(f"**Total de columnas**: {len(df.columns)}")
                cols_display = st.columns(4)
                for i, col in enumerate(df.columns):
                    with cols_display[i % 4]:
                        st.write(f"• {col}")
            
            # Análisis estadístico
            st.header("📊 Análisis Estadístico")
            
            with st.spinner("Calculando estadísticas..."):
                resultados, variables_encontradas, variables_no_encontradas = calcular_estadisticas(df)
            
            if not resultados.empty:
                # Mostrar estadísticas
                st.subheader("📈 Estadísticas Descriptivas")
                st.dataframe(
                    resultados,
                    use_container_width=True,
                    hide_index=True
                )
                
                # Botón para descargar resultados
                csv_buffer = io.StringIO()
                resultados.to_csv(csv_buffer, index=False)
                st.download_button(
                    label="📥 Descargar estadísticas como CSV",
                    data=csv_buffer.getvalue(),
                    file_name=f"estadisticas_{uploaded_file.name}",
                    mime="text/csv"
                )
                
                # Resumen
                st.subheader("📋 Resumen del Análisis")
                col1, col2 = st.columns(2)
                
                with col1:
                    st.success(f"✅ **Variables encontradas**: {len(variables_encontradas)}")
                    if variables_encontradas:
                        for var in variables_encontradas:
                            st.write(f"• {var}")
                
                with col2:
                    if variables_no_encontradas:
                        st.warning(f"⚠️ **Variables no encontradas**: {len(variables_no_encontradas)}")
                        for var in variables_no_encontradas:
                            st.write(f"• {var}")
                
                # Visualizaciones
                if variables_encontradas:
                    st.header("📊 Visualizaciones")
                    
                    # Histogramas
                    st.subheader("📈 Distribuciones")
                    fig_hist = crear_graficos(df, variables_encontradas)
                    if fig_hist:
                        st.plotly_chart(fig_hist, use_container_width=True)
                    
                    # Boxplots
                    st.subheader("📦 Boxplots")
                    fig_box = crear_boxplots(df, variables_encontradas)
                    if fig_box:
                        st.plotly_chart(fig_box, use_container_width=True)
                    
                    # Matriz de correlación
                    if len(variables_encontradas) >= 2:
                        st.subheader("🔗 Matriz de Correlación")
                        fig_corr = crear_matriz_correlacion(df, variables_encontradas)
                        if fig_corr:
                            st.plotly_chart(fig_corr, use_container_width=True)
                
                # Análisis por variable
                st.header("🔍 Análisis Detallado por Variable")
                
                variable_seleccionada = st.selectbox(
                    "Selecciona una variable para análisis detallado:",
                    variables_encontradas
                )
                
                if variable_seleccionada:
                    data_var = pd.to_numeric(df[variable_seleccionada], errors='coerce').dropna()
                    
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.subheader(f"📊 Estadísticas de {variable_seleccionada}")
                        stats_dict = {
                            "N válidos": len(data_var),
                            "Media": round(data_var.mean(), 3),
                            "Mediana": round(data_var.median(), 3),
                            "Desv. Estándar": round(data_var.std(), 3),
                            "Varianza": round(data_var.var(), 3),
                            "Mínimo": data_var.min(),
                            "Máximo": data_var.max(),
                            "Rango": data_var.max() - data_var.min(),
                            "Q1": round(data_var.quantile(0.25), 3),
                            "Q3": round(data_var.quantile(0.75), 3),
                            "Asimetría": round(data_var.skew(), 3),
                            "Curtosis": round(data_var.kurtosis(), 3)
                        }
                        
                        for key, value in stats_dict.items():
                            st.metric(key, value)
                    
                    with col2:
                        st.subheader(f"📈 Distribución de {variable_seleccionada}")
                        fig_individual = px.histogram(
                            x=data_var, 
                            nbins=30,
                            title=f"Distribución de {variable_seleccionada}"
                        )
                        st.plotly_chart(fig_individual, use_container_width=True)
                
            else:
                st.error("❌ No se encontraron variables válidas para analizar")
                st.info("Verifica que tu archivo CSV contenga las variables especificadas")
        
        except Exception as e:
            st.error(f"❌ Error al procesar el archivo: {str(e)}")
            st.info("Verifica que el archivo sea un CSV válido")

if __name__ == "__main__":
    main()